import {Friends} from "./friends";

$(document).ready(function ()
{
    let friends = new Friends();
});