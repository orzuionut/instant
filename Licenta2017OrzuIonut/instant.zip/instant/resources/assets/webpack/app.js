import {Notification} from './modules/notification';

$(document).ready(function ()
{
    let notification = new Notification();

    $(".button-collapse").sideNav();
});