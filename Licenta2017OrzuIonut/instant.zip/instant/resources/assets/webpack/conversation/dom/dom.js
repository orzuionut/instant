class ConversationDOM {

    constructor(body, footer)
    {
        this.body = body;
        this.footer = footer;
    }
}

export { ConversationDOM }